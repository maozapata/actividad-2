package actividad2;

import java.util.ArrayList;
import java.util.Scanner;

class Jugador {
    private static int idCounter = 0;
    private int id;
    private String nombre;
    private int edad;
    private String equipo;

    public Jugador(String nombre, int edad, String equipo) {
        this.id = ++idCounter;
        this.nombre = nombre;
        this.edad = edad;
        this.equipo = equipo;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getEquipo() {
        return equipo;
    }

    public void setEquipo(String equipo) {
        this.equipo = equipo;
    }

    @Override
    public String toString() {
        return "Jugador{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                ", edad=" + edad +
                ", equipo='" + equipo + '\'' +
                '}';
    }
}

public class Main {
    private static ArrayList<Jugador> jugadores = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        int opcion;
        do {
            mostrarMenu();
            opcion = scanner.nextInt();
            scanner.nextLine(); // Consume newline
            switch (opcion) {
                case 1:
                    agregarJugador();
                    break;
                case 2:
                    eliminarJugador();
                    break;
                case 3:
                    buscarJugador();
                    break;
                case 4:
                    editarJugador();
                    break;
                case 5:
                    listarJugadores();
                    break;
                case 6:
                    System.out.println("Saliendo del programa...");
                    break;
                default:
                    System.out.println("Opción inválida, por favor intente de nuevo.");
            }
        } while (opcion != 6);
    }

    private static void mostrarMenu() {
        System.out.println("Menu:");
        System.out.println("1. Agregar jugador");
        System.out.println("2. Eliminar jugador");
        System.out.println("3. Buscar jugador");
        System.out.println("4. Editar jugador");
        System.out.println("5. Listar todos los jugadores");
        System.out.println("6. Salir");
        System.out.print("Seleccione una opción: ");
    }

    private static void agregarJugador() {
        System.out.print("Ingrese el nombre del jugador: ");
        String nombre = scanner.nextLine();
        System.out.print("Ingrese la edad del jugador: ");
        int edad = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Ingrese el equipo del jugador: ");
        String equipo = scanner.nextLine();

        Jugador jugador = new Jugador(nombre, edad, equipo);
        jugadores.add(jugador);

        System.out.println("Jugador agregado con éxito:");
        listarJugadores();
    }

    private static void eliminarJugador() {
        System.out.print("Ingrese el ID del jugador a eliminar: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        Jugador jugador = buscarJugadorPorId(id);
        if (jugador != null) {
            System.out.print("¿Está seguro que desea eliminar al jugador " + jugador.getNombre() + "? (s/n): ");
            String confirmacion = scanner.nextLine();
            if (confirmacion.equalsIgnoreCase("s")) {
                jugadores.remove(jugador);
                System.out.println("Jugador eliminado con éxito.");
                listarJugadores();
            } else {
                System.out.println("Eliminación cancelada.");
            }
        } else {
            System.out.println("Jugador no encontrado.");
        }
    }

    private static void buscarJugador() {
        System.out.print("Ingrese el ID del jugador a buscar: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        Jugador jugador = buscarJugadorPorId(id);
        if (jugador != null) {
            System.out.println("Jugador encontrado:");
            System.out.println(jugador);
        } else {
            System.out.println("Jugador no encontrado.");
        }
    }

    private static Jugador buscarJugadorPorId(int id) {
        for (Jugador jugador : jugadores) {
            if (jugador.getId() == id) {
                return jugador;
            }
        }
        return null;
    }

    private static void editarJugador() {
        System.out.print("Ingrese el ID del jugador a editar: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        Jugador jugador = buscarJugadorPorId(id);
        if (jugador != null) {
            System.out.println("Jugador encontrado:");
            System.out.println(jugador);

            System.out.print("Ingrese el nuevo nombre (deje vacío para no cambiar): ");
            String nombre = scanner.nextLine();
            if (!nombre.isEmpty()) {
                jugador.setNombre(nombre);
            }

            System.out.print("Ingrese la nueva edad (0 para no cambiar): ");
            int edad = scanner.nextInt();
            scanner.nextLine(); // Consume newline
            if (edad != 0) {
                jugador.setEdad(edad);
            }

            System.out.print("Ingrese el nuevo equipo (deje vacío para no cambiar): ");
            String equipo = scanner.nextLine();
            if (!equipo.isEmpty()) {
                jugador.setEquipo(equipo);
            }

            System.out.println("Jugador editado con éxito.");
            listarJugadores();
        } else {
            System.out.println("Jugador no encontrado.");
        }
    }

    private static void listarJugadores() {
        System.out.println("Listado de jugadores:");
        for (Jugador jugador : jugadores) {
            System.out.println(jugador);
        }
    }
}
