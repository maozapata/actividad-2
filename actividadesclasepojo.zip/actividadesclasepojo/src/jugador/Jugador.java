package jugador;

 public class Jugador {
    private int id;
    private String nombre;
    private int edad;
    private String equipo;

    public Jugador(int id, String nombre, int edad, String equipo) {
        this.id = id;
        this.nombre = nombre;
        this.edad = edad;
        this.equipo = equipo;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getEquipo() {
        return equipo;
    }

    public void setEquipo(String equipo) {
        this.equipo = equipo;
    }

    public String toString() {
        return "Jugador{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                ", edad=" + edad +
                ", equipo='" + equipo + '\'' +
                '}';
    }
}
