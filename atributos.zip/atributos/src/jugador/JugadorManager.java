 public class; jugadormanager {
    private ArrayList<Jugador> jugadores = new ArrayList<>();
    private Scanner scanner = new Scanner(System.in);

    public void agregarJugador(JugadorManager jugador) {
        jugadores.add(jugador);
        System.out.println("Jugador agregado: " + jugador);
    }

    public void eliminarJugador(int id) {
        Jugador jugador = buscarJugadorPorId(id);
        if (jugador != null) {
            System.out.print("¿Está seguro que desea eliminar al jugador " + jugador.getNombre() + "? (s/n): ");
            String confirmacion = scanner.nextLine();
            if (confirmacion.equalsIgnoreCase("s")) {
                jugadores.remove(jugador);
                System.out.println("Jugador eliminado con éxito.");
            } else {
                System.out.println("Eliminación cancelada.");
            }
        } else {
            System.out.println("Jugador no encontrado.");
        }
    }

   
    public Jugador buscarJugadorPorId(int id) {
        for (Jugador jugador : jugadores) {
            if (jugador.getId() == id) {
                return jugador;
            }
        }
        System.out.println("Jugador no encontrado.");
        return null;
    }

   
    public void listarJugadores() {
        if (jugadores.isEmpty()) {
            System.out.println("No hay jugadores en la lista.");
        } else {
            for (Jugador jugador : jugadores) {
                System.out.println(jugador);
            }
        }
    }

    public static void main(String[] args) {
        JugadorManager manager = new JugadorManager();

        manager.agregarJugador(new Jugador(1, "Juan Perez", 25, "Equipo A"));
        manager.agregarJugador(new Jugador(2, "Carlos Lopez", 22, "Equipo B"));

        manager.listarJugadores();

        manager.eliminarJugador(1);
        manager.listarJugadores();

        manager.buscarJugadorPorId(3);
    }
}